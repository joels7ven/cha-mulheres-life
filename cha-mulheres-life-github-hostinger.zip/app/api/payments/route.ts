import { env } from "cloudflare:workers";
import { createOrder, updateOrderPayment } from "@/db/orders";

const UNIT_PRICE = 100;

type PaymentRequest = {
  formData?: Record<string, unknown>;
  buyer?: { name?: string; email?: string; phone?: string };
  attendees?: Array<{ fullName?: string; cpf?: string }>;
};

function digits(value: string) { return value.replace(/\D/g, ""); }

export async function POST(request: Request) {
  const accessToken = (env as unknown as { MERCADO_PAGO_ACCESS_TOKEN?: string }).MERCADO_PAGO_ACCESS_TOKEN;
  if (!accessToken) return Response.json({ error: "O pagamento ainda não foi ativado." }, { status: 503 });

  let body: PaymentRequest;
  try { body = await request.json() as PaymentRequest; }
  catch { return Response.json({ error: "Dados inválidos." }, { status: 400 }); }

  const attendees = body.attendees ?? [];
  const buyer = body.buyer ?? {};
  const formData = body.formData ?? {};
  if (attendees.length < 1 || attendees.length > 10) return Response.json({ error: "Escolha entre 1 e 10 ingressos." }, { status: 400 });
  if (!buyer.name?.trim() || !buyer.email?.includes("@") || digits(buyer.phone ?? "").length < 10) return Response.json({ error: "Confira os dados da pessoa responsável pela compra." }, { status: 400 });
  if (attendees.some((person) => !person.fullName?.trim() || digits(person.cpf ?? "").length !== 11)) return Response.json({ error: "Informe nome e CPF válidos de todas as participantes." }, { status: 400 });

  const orderId = crypto.randomUUID();
  const total = attendees.length * UNIT_PRICE;
  await createOrder({
    id: orderId,
    buyerName: buyer.name.trim(),
    buyerEmail: buyer.email.trim().toLowerCase(),
    buyerPhone: digits(buyer.phone ?? ""),
    quantity: attendees.length,
    totalCents: total * 100,
    attendees: attendees.map((person) => ({ fullName: person.fullName!.trim(), cpf: digits(person.cpf ?? "") })),
  });

  const paymentPayload = {
    ...formData,
    transaction_amount: total,
    description: "Chá das Mulheres Life",
    external_reference: orderId,
    notification_url: `${new URL(request.url).origin}/api/webhooks/mercadopago`,
    payer: {
      ...((formData.payer as Record<string, unknown> | undefined) ?? {}),
      email: buyer.email.trim().toLowerCase(),
    },
    metadata: { order_id: orderId, ticket_quantity: attendees.length },
  };

  const response = await fetch("https://api.mercadopago.com/v1/payments", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Idempotency-Key": orderId,
    },
    body: JSON.stringify(paymentPayload),
  });
  const result = await response.json() as Record<string, unknown>;
  if (!response.ok) {
    await updateOrderPayment(orderId, String(result.id ?? ""), "error");
    return Response.json({ error: "Não foi possível concluir o pagamento. Confira os dados e tente novamente." }, { status: 400 });
  }

  const paymentId = String(result.id ?? "");
  const status = String(result.status ?? "pending");
  await updateOrderPayment(orderId, paymentId, status);
  const transactionData = ((result.point_of_interaction as Record<string, unknown> | undefined)?.transaction_data ?? {}) as Record<string, unknown>;
  return Response.json({
    orderId,
    paymentId,
    status,
    statusDetail: result.status_detail ?? null,
    pix: transactionData.qr_code ? {
      qrCode: String(transactionData.qr_code),
      qrCodeBase64: String(transactionData.qr_code_base64 ?? ""),
      ticketUrl: String(transactionData.ticket_url ?? ""),
    } : null,
  });
}
