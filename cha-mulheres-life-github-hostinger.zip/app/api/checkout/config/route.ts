import { env } from "cloudflare:workers";

export async function GET() {
  const publicKey = (env as unknown as { MERCADO_PAGO_PUBLIC_KEY?: string }).MERCADO_PAGO_PUBLIC_KEY;
  return Response.json({
    available: Boolean(publicKey),
    publicKey: publicKey ?? null,
    unitPrice: 100,
    maxQuantity: 10,
  });
}
