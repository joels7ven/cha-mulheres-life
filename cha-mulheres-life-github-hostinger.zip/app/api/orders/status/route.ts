import { findOrder } from "@/db/orders";

export async function GET(request: Request) {
  const orderId = new URL(request.url).searchParams.get("orderId") ?? "";
  if (!/^[0-9a-f-]{36}$/i.test(orderId)) return Response.json({ error: "Pedido inválido." }, { status: 400 });
  const order = await findOrder(orderId);
  if (!order) return Response.json({ error: "Pedido não encontrado." }, { status: 404 });
  return Response.json({ status: String(order.status ?? "pending") }, { headers: { "Cache-Control": "no-store" } });
}
