import { env } from "cloudflare:workers";
import { findOrder, updateOrderPayment } from "@/db/orders";

export async function POST(request: Request) {
  const accessToken = (env as unknown as { MERCADO_PAGO_ACCESS_TOKEN?: string }).MERCADO_PAGO_ACCESS_TOKEN;
  if (!accessToken) return new Response(null, { status: 503 });

  const url = new URL(request.url);
  let body: { data?: { id?: string | number } } = {};
  try { body = await request.json() as typeof body; } catch { /* query fallback */ }
  const paymentId = String(body.data?.id ?? url.searchParams.get("data.id") ?? "");
  if (!paymentId) return new Response(null, { status: 200 });

  const response = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, {
    headers: { "Authorization": `Bearer ${accessToken}` },
  });
  if (!response.ok) return new Response(null, { status: 200 });
  const payment = await response.json() as { external_reference?: string; status?: string; id?: string | number };
  if (!payment.external_reference || !(await findOrder(payment.external_reference))) return new Response(null, { status: 200 });
  await updateOrderPayment(payment.external_reference, String(payment.id ?? paymentId), payment.status ?? "pending");
  return new Response(null, { status: 200 });
}
