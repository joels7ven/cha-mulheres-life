"use client";

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";

declare global {
  interface Window {
    MercadoPago?: new (publicKey: string, options?: { locale?: string }) => {
      bricks: () => {
        create: (type: string, container: string, settings: Record<string, unknown>) => Promise<{ unmount: () => void }>;
      };
    };
  }
}

type Attendee = { fullName: string; cpf: string };
type Buyer = { name: string; email: string; phone: string };
type Config = { available: boolean; publicKey: string | null; unitPrice: number; maxQuantity: number };

const emptyAttendee = (): Attendee => ({ fullName: "", cpf: "" });

function formatCpf(value: string) {
  return value.replace(/\D/g, "").slice(0, 11).replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

function formatPhone(value: string) {
  return value.replace(/\D/g, "").slice(0, 11).replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
}

function loadMercadoPago() {
  if (window.MercadoPago) return Promise.resolve();
  return new Promise<void>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>('script[src="https://sdk.mercadopago.com/js/v2"]');
    if (existing) { existing.addEventListener("load", () => resolve(), { once: true }); return; }
    const script = document.createElement("script");
    script.src = "https://sdk.mercadopago.com/js/v2";
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Não foi possível carregar o pagamento."));
    document.head.appendChild(script);
  });
}

export default function CheckoutExperience() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<"details" | "payment" | "result">("details");
  const [quantity, setQuantity] = useState(1);
  const [buyer, setBuyer] = useState<Buyer>({ name: "", email: "", phone: "" });
  const [attendees, setAttendees] = useState<Attendee[]>([emptyAttendee()]);
  const [config, setConfig] = useState<Config | null>(null);
  const [message, setMessage] = useState("");
  const [result, setResult] = useState<{ status: string; orderId?: string; pix?: { qrCode: string; qrCodeBase64: string; ticketUrl: string } | null } | null>(null);
  const [copied, setCopied] = useState(false);
  const brickRef = useRef<{ unmount: () => void } | null>(null);
  const total = useMemo(() => quantity * 100, [quantity]);

  function changeQuantity(next: number) {
    const value = Math.max(1, Math.min(10, next));
    setQuantity(value);
    setAttendees((current) => Array.from({ length: value }, (_, index) => current[index] ?? emptyAttendee()));
  }

  function close() {
    brickRef.current?.unmount();
    brickRef.current = null;
    setOpen(false);
    setStep("details");
    setMessage("");
  }

  async function continueToPayment(event: FormEvent) {
    event.preventDefault();
    setMessage("");
    const validBuyer = buyer.name.trim().length > 2 && buyer.email.includes("@") && buyer.phone.replace(/\D/g, "").length >= 10;
    const validAttendees = attendees.every((person) => person.fullName.trim().length > 2 && person.cpf.replace(/\D/g, "").length === 11);
    if (!validBuyer || !validAttendees) { setMessage("Confira os dados da compra e de todas as participantes."); return; }
    const response = await fetch("/api/checkout/config");
    const nextConfig = await response.json() as Config;
    setConfig(nextConfig);
    setStep("payment");
  }

  useEffect(() => {
    if (step !== "payment" || !config?.available || !config.publicKey || brickRef.current) return;
    let cancelled = false;
    loadMercadoPago().then(async () => {
      if (cancelled || !window.MercadoPago || !config.publicKey) return;
      const mercadoPago = new window.MercadoPago(config.publicKey, { locale: "pt-BR" });
      brickRef.current = await mercadoPago.bricks().create("payment", "paymentBrick_container", {
        initialization: { amount: total, payer: { email: buyer.email } },
        customization: {
          visual: { style: { theme: "default" } },
          paymentMethods: { creditCard: "all", debitCard: "all", bankTransfer: ["pix"], maxInstallments: 10 },
        },
        callbacks: {
          onReady: () => setMessage(""),
          onError: () => setMessage("Não foi possível carregar o checkout. Tente novamente."),
          onSubmit: async ({ formData }: { formData: Record<string, unknown> }) => {
            setMessage("");
            const response = await fetch("/api/payments", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ formData, buyer, attendees }),
            });
            const data = await response.json() as { error?: string; status?: string; orderId?: string; pix?: { qrCode: string; qrCodeBase64: string; ticketUrl: string } | null };
            if (!response.ok) { setMessage(data.error ?? "Não foi possível concluir o pagamento."); throw new Error(data.error); }
            setResult({ status: data.status ?? "pending", orderId: data.orderId, pix: data.pix });
            setStep("result");
          },
        },
      });
    }).catch(() => setMessage("Não foi possível carregar o checkout. Tente novamente."));
    return () => { cancelled = true; };
  }, [step, config, total, buyer, attendees]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") close(); };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", onKey); };
  }, [open]);

  useEffect(() => {
    if (step !== "result" || !result?.orderId || result.status === "approved") return;
    const timer = window.setInterval(async () => {
      const response = await fetch(`/api/orders/status?orderId=${encodeURIComponent(result.orderId!)}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { status: string };
      if (data.status === "approved") setResult((current) => current ? { ...current, status: "approved" } : current);
    }, 5000);
    return () => window.clearInterval(timer);
  }, [step, result?.orderId, result?.status]);

  return (
    <>
      <button className="button ticket-button" type="button" onClick={() => setOpen(true)}>Comprar ingresso <span>→</span></button>
      {open && (
        <div className="checkout-overlay" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
          <button className="checkout-backdrop" type="button" aria-label="Fechar checkout" onClick={close} />
          <section className="checkout-modal">
            <header className="checkout-header">
              <div><span>Chá das Mulheres Life</span><strong id="checkout-title">Garanta seu lugar</strong></div>
              <button type="button" onClick={close} aria-label="Fechar">×</button>
            </header>
            <div className="checkout-progress" aria-label={`Etapa ${step === "details" ? 1 : 2} de 2`}><i className={step !== "details" ? "done" : "active"} /><i className={step === "payment" || step === "result" ? "active" : ""} /></div>

            {step === "details" && (
              <form className="checkout-form" onSubmit={continueToPayment}>
                <div className="checkout-summary">
                  <div><small>1º lote • até 20/08</small><strong>R$ 100,00 <span>por pessoa</span></strong></div>
                  <label>Quantidade de ingressos<select value={quantity} onChange={(event) => changeQuantity(Number(event.target.value))}>{Array.from({ length: 10 }, (_, index) => <option key={index + 1} value={index + 1}>{index + 1}</option>)}</select></label>
                </div>
                <fieldset><legend>Responsável pela compra</legend><p>Esta pessoa receberá a confirmação do pagamento.</p>
                  <label>Nome completo<input required autoComplete="name" value={buyer.name} onChange={(event) => setBuyer({ ...buyer, name: event.target.value })} /></label>
                  <div className="field-row"><label>E-mail<input required type="email" autoComplete="email" value={buyer.email} onChange={(event) => setBuyer({ ...buyer, email: event.target.value })} /></label><label>WhatsApp<input required inputMode="tel" autoComplete="tel" placeholder="(65) 99999-9999" value={buyer.phone} onChange={(event) => setBuyer({ ...buyer, phone: formatPhone(event.target.value) })} /></label></div>
                </fieldset>
                <fieldset><legend>Dados das participantes</legend><p>O ingresso é individual. Preencha nome e CPF de cada participante.</p>
                  {attendees.map((person, index) => <div className="attendee" key={index}><b>{String(index + 1).padStart(2, "0")}</b><label>Nome completo<input required value={person.fullName} onChange={(event) => setAttendees(attendees.map((item, itemIndex) => itemIndex === index ? { ...item, fullName: event.target.value } : item))} /></label><label>CPF<input required inputMode="numeric" placeholder="000.000.000-00" value={person.cpf} onChange={(event) => setAttendees(attendees.map((item, itemIndex) => itemIndex === index ? { ...item, cpf: formatCpf(event.target.value) } : item))} /></label></div>)}
                </fieldset>
                {message && <p className="checkout-error" role="alert">{message}</p>}
                <div className="checkout-total"><span>Total</span><strong>{total.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</strong></div>
                <button className="button checkout-next" type="submit">Ir para o pagamento <span>→</span></button>
              </form>
            )}

            {step === "payment" && (
              <div className="payment-step">
                <button className="back-link" type="button" onClick={() => { brickRef.current?.unmount(); brickRef.current = null; setStep("details"); }}>← Revisar participantes</button>
                <div className="payment-order"><span>{quantity} {quantity === 1 ? "ingresso" : "ingressos"}</span><strong>{total.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</strong></div>
                {config?.available ? <div id="paymentBrick_container" /> : <div className="activation-notice"><span>Pagamento preparado</span><strong>Falta conectar as credenciais do Mercado Pago</strong><p>Os dados da inscrição estão prontos. Assim que as chaves forem adicionadas, Pix e cartão aparecerão aqui automaticamente.</p></div>}
                {message && <p className="checkout-error" role="alert">{message}</p>}
              </div>
            )}

            {step === "result" && <div className="checkout-result">
              {result?.pix && result.status !== "approved" ? <>
                <span className="pix-status">Pix gerado</span>
                <h3>Escaneie para pagar</h3>
                <p>Abra o aplicativo do seu banco e leia o QR Code. A confirmação acontece automaticamente.</p>
                {result.pix.qrCodeBase64 && <img className="pix-qr" src={`data:image/png;base64,${result.pix.qrCodeBase64}`} alt="QR Code Pix para pagamento" />}
                <div className="pix-copy"><input aria-label="Código Pix Copia e Cola" readOnly value={result.pix.qrCode} /><button type="button" onClick={async () => { await navigator.clipboard.writeText(result.pix!.qrCode); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }}>{copied ? "Copiado!" : "Copiar código"}</button></div>
                <small className="waiting-payment"><i /> Aguardando confirmação do pagamento…</small>
              </> : <>
                <span>{result?.status === "approved" ? "✓" : "⌛"}</span>
                <h3>{result?.status === "approved" ? "Pagamento aprovado!" : "Pagamento em processamento"}</h3>
                <p>{result?.status === "approved" ? "Seus ingressos foram confirmados. Guarde o número abaixo." : "Avisaremos quando o Mercado Pago confirmar sua compra."}</p>
              </>}
              <code>{result?.orderId}</code><button className="button" type="button" onClick={close}>Voltar ao site</button>
            </div>}
          </section>
        </div>
      )}
    </>
  );
}
