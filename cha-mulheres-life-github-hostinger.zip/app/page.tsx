import CheckoutExperience from "./CheckoutExperience";

const highlights = [
  {
    number: "01",
    title: "Palavra que floresce",
    text: "Uma mensagem preparada para renovar a fé, fortalecer a identidade e inspirar novos começos.",
  },
  {
    number: "02",
    title: "Mesa & comunhão",
    text: "Um chá especial, preparado com carinho para criar conversas leves e encontros que permanecem.",
  },
  {
    number: "03",
    title: "Conexões reais",
    text: "Um ambiente seguro para celebrar histórias, construir amizades e lembrar que ninguém caminha sozinha.",
  },
];

const faqs = [
  ["Quem pode participar?", "O encontro é aberto a mulheres de todas as idades. Você não precisa ser membro da Igreja Batista Life para participar."],
  ["O ingresso inclui o chá?", "Sim. A experiência do evento e o chá servido durante a programação estão incluídos no ingresso."],
  ["Como recebo meu ingresso?", "Após a confirmação do pagamento, você receberá os dados da inscrição no e-mail informado no checkout."],
  ["Posso comprar para outra pessoa?", "Sim. Na etapa de inscrição, você poderá informar os dados da participante que receberá o ingresso."],
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#inicio" aria-label="Chá das Mulheres — início">
          <span className="brand-mark">L</span>
          <span><strong>Chá das Mulheres</strong><small>Igreja Batista Life</small></span>
        </a>
        <nav aria-label="Navegação principal">
          <a href="#experiencia">A experiência</a>
          <a href="#detalhes">Detalhes</a>
          <a href="#duvidas">Dúvidas</a>
        </nav>
        <a className="button button-small" href="#ingressos">Quero participar</a>
      </header>

      <section className="hero" id="inicio">
        <div className="hero-ornament ornament-one" aria-hidden="true" />
        <div className="hero-ornament ornament-two" aria-hidden="true" />
        <div className="hero-copy">
          <p className="eyebrow">Igreja Batista Life apresenta</p>
          <h1>Há encontros que<br /><em>fazem a alma florescer.</em></h1>
          <p className="hero-text">Uma tarde criada para mulheres que desejam desacelerar, fortalecer a fé e viver conexões que transformam.</p>
          <div className="hero-actions">
            <a className="button" href="#ingressos">Garantir meu lugar <span>→</span></a>
            <a className="text-link" href="#experiencia">Conhecer a experiência <span>↓</span></a>
          </div>
        </div>
        <aside className="event-card" aria-label="Informações principais do evento">
          <div className="card-flower" aria-hidden="true"><i /><i /><i /><i /><b /></div>
          <p className="script">Você é nossa convidada</p>
          <div className="card-title">Chá<br />das Mulheres</div>
          <div className="card-rule" />
          <dl>
            <div><dt>Data</dt><dd>19 de setembro</dd></div>
            <div><dt>Horário</dt><dd>16 horas</dd></div>
            <div><dt>Local</dt><dd>Tangará da Serra • MT</dd></div>
          </dl>
          <p className="card-foot">Life • uma igreja para pertencer</p>
        </aside>
        <div className="scroll-cue" aria-hidden="true"><span>Descubra</span><i /></div>
      </section>

      <section className="intro" id="experiencia">
        <div className="section-label"><span>01</span> Sobre o encontro</div>
        <div className="intro-copy">
          <p className="kicker">Uma pausa. Um respiro. Um recomeço.</p>
          <h2>Você cuida de tanta gente.<br />Desta vez, <em>o convite é para você.</em></h2>
          <p>O Chá das Mulheres Life é um encontro pensado nos detalhes: uma mesa bonita, uma palavra que encontra o coração e a alegria de dividir a caminhada com outras mulheres.</p>
        </div>
      </section>

      <section className="highlights">
        {highlights.map((item) => (
          <article key={item.number}>
            <span>{item.number}</span>
            <div className={`mini-art mini-art-${item.number}`} aria-hidden="true"><i /><b /></div>
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </article>
        ))}
      </section>

      <section className="verse">
        <div className="verse-rings" aria-hidden="true" />
        <p>“Deus está no meio dela;<br /><em>não será abalada.</em>”</p>
        <span>Salmos 46:5</span>
      </section>

      <section className="details" id="detalhes">
        <div className="details-copy">
          <div className="section-label"><span>02</span> Programe-se</div>
          <p className="kicker">Tudo o que você precisa saber</p>
          <h2>Prepare o coração.<br /><em>Nós cuidamos do restante.</em></h2>
          <p>No dia 19 de setembro, às 16h, a Igreja Batista Life recebe você para uma tarde de fé, comunhão e novos começos. Chegue com o coração aberto — seu lugar à mesa já está sendo preparado.</p>
        </div>
        <div className="info-grid">
          <div><span>Data</span><strong>19 de setembro</strong><small>Sábado</small></div>
          <div><span>Horário</span><strong>16 horas</strong><small>Programação especial</small></div>
          <div className="wide"><span>Local</span><strong>Igreja Batista Life</strong><small>Rua José Florêncio (15), 53-E • Centro • Tangará da Serra–MT</small></div>
        </div>
      </section>

      <section className="tickets" id="ingressos">
        <div className="ticket-heading">
          <div className="section-label light"><span>03</span> Seu lugar à mesa</div>
          <h2>Viva esta tarde<br /><em>com a gente.</em></h2>
          <p>Garanta seu ingresso no primeiro lote até 20 de agosto. Compre até 10 lugares de uma só vez e informe os dados individuais de cada participante.</p>
        </div>
        <div className="ticket-card">
          <span className="ticket-tag">1º lote • até 20/08</span>
          <p>Ingresso individual</p>
          <div className="price"><small>R$</small><strong>100</strong><sup>,00</sup></div>
          <ul>
            <li>Acesso à programação completa</li>
            <li>Chá e experiência à mesa</li>
            <li>Momentos de palavra e comunhão</li>
          </ul>
          <CheckoutExperience />
          <small className="secure-note">Pagamento seguro via Mercado Pago</small>
        </div>
      </section>

      <section className="faq" id="duvidas">
        <div>
          <div className="section-label"><span>04</span> Perguntas frequentes</div>
          <h2>Ainda ficou<br /><em>alguma dúvida?</em></h2>
          <p>Fale com a equipe da Igreja Batista Life pelos nossos canais oficiais.</p>
        </div>
        <div className="faq-list">
          {faqs.map(([question, answer], index) => (
            <details key={question} open={index === 0}>
              <summary><span>{question}</span><b>+</b></summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="closing">
        <p className="script">Seu lugar está sendo preparado</p>
        <h2>Uma tarde para<br /><em>guardar no coração.</em></h2>
        <a className="button button-cream" href="#ingressos">Quero viver esse encontro <span>→</span></a>
      </section>

      <footer>
        <a className="brand footer-brand" href="#inicio"><span className="brand-mark">L</span><span><strong>Igreja Batista Life</strong><small>Tangará da Serra • MT</small></span></a>
        <p>Chá das Mulheres Life</p>
        <p>Feito com propósito, fé e carinho.</p>
      </footer>

      <a className="mobile-cta" href="#ingressos">Quero participar <span>→</span></a>
    </main>
  );
}
