import type { Metadata } from "next";
import { Geist } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";

const geist = Geist({
  variable: "--font-geist",
  subsets: ["latin"],
});

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const imageUrl = `${protocol}://${host}/og.png`;

  return {
    title: "Chá das Mulheres | Igreja Batista Life",
    description: "Uma tarde de fé, comunhão e novos começos para mulheres, em Tangará da Serra.",
    icons: { icon: "/favicon.svg" },
    openGraph: {
      title: "Chá das Mulheres | Igreja Batista Life",
      description: "Uma tarde para a alma florescer.",
      type: "website",
      locale: "pt_BR",
      images: [{ url: imageUrl, width: 1734, height: 907, alt: "Chá das Mulheres — Igreja Batista Life" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "Chá das Mulheres | Igreja Batista Life",
      description: "Uma tarde para a alma florescer.",
      images: [imageUrl],
    },
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body className={geist.variable}>{children}</body>
    </html>
  );
}
