import { env } from "cloudflare:workers";

type D1ResultRow = Record<string, unknown>;

function database(): D1Database {
  const binding = (env as unknown as { DB?: D1Database }).DB;
  if (!binding) throw new Error("Banco de dados indisponível.");
  return binding;
}

export async function createOrder(input: {
  id: string;
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  quantity: number;
  totalCents: number;
  attendees: Array<{ fullName: string; cpf: string }>;
}) {
  const db = database();
  const now = new Date().toISOString();
  const statements = [
    db.prepare("INSERT INTO orders (id, buyer_name, buyer_email, buyer_phone, quantity, total_cents, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 'created', ?, ?)")
      .bind(input.id, input.buyerName, input.buyerEmail, input.buyerPhone, input.quantity, input.totalCents, now, now),
    ...input.attendees.map((attendee) =>
      db.prepare("INSERT INTO attendees (id, order_id, full_name, cpf) VALUES (?, ?, ?, ?)")
        .bind(crypto.randomUUID(), input.id, attendee.fullName, attendee.cpf),
    ),
  ];
  await db.batch(statements);
}

export async function updateOrderPayment(orderId: string, paymentId: string, status: string) {
  await database().prepare("UPDATE orders SET mercado_pago_payment_id = ?, status = ?, updated_at = ? WHERE id = ?")
    .bind(paymentId, status, new Date().toISOString(), orderId).run();
}

export async function findOrder(orderId: string): Promise<D1ResultRow | null> {
  return database().prepare("SELECT * FROM orders WHERE id = ?").bind(orderId).first<D1ResultRow>();
}
