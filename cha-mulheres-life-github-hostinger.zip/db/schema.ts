import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(),
  buyerName: text("buyer_name").notNull(),
  buyerEmail: text("buyer_email").notNull(),
  buyerPhone: text("buyer_phone").notNull(),
  quantity: integer("quantity").notNull(),
  totalCents: integer("total_cents").notNull(),
  status: text("status").notNull().default("created"),
  mercadoPagoPaymentId: text("mercado_pago_payment_id"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const attendees = sqliteTable("attendees", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id),
  fullName: text("full_name").notNull(),
  cpf: text("cpf").notNull(),
});
