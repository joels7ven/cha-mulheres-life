CREATE TABLE `attendees` (
	`id` text PRIMARY KEY NOT NULL,
	`order_id` text NOT NULL,
	`full_name` text NOT NULL,
	`cpf` text NOT NULL,
	FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`buyer_name` text NOT NULL,
	`buyer_email` text NOT NULL,
	`buyer_phone` text NOT NULL,
	`quantity` integer NOT NULL,
	`total_cents` integer NOT NULL,
	`status` text DEFAULT 'created' NOT NULL,
	`mercado_pago_payment_id` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
